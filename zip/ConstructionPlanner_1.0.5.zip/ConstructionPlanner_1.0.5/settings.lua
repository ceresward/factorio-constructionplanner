-- settings.lua 

data:extend({
	{
        setting_type = "runtime-per-user",
		name = "constructionPlanner-auto-approve",
        type = "bool-setting",
        default_value = false
    },
})